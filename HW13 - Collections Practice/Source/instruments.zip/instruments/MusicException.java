package instruments;

public class MusicException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1522631145483759202L;

	public MusicException() {
		// TODO Auto-generated constructor stub
	}

	public MusicException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MusicException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MusicException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public MusicException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
