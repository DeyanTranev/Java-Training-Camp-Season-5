package instruments;

public enum InstrumentType {
	Strunni, Udarni, Duhovi, Klavishni, Elektronni
}
