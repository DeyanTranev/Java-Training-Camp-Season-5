package warehouse;

public enum ProductType {
	FRUITS, VEGETABLES, MEATS;
}
