
public class Task {
	private String name;
	private double workingHours;
	
	public void setName(String name) {
		if(name != null && name != "") {
			this.name = name;
		}
		else {
			this.name="Undefined Task";
		}
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setWorkingHours(double hours) {
		if (hours>=0) {
			this.workingHours=hours;
		}
	
	}
	
	public double getWorkingHours() {
		return this.workingHours;
	}
	public Task(String name, double workingHours) {
		this.setName(name);
		this.setWorkingHours(workingHours);
	}
	
}
