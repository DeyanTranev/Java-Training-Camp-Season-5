
public class Employee {
	private String name;
	private Task currentTask;
	private double hoursLeft;
	public static final double MAX_DAILY_HOURS = 8.0;
	
	public void setName(String name){
		if(name!=null && name.length() > 2) {
			this.name = name;
		}
		else {
			this.name = "Default Name";
		}
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setCurrentTask(Task task) {
		if (task != null) {
			this.currentTask = task;
		}
	}
	
	public String getCurrentTask() {
		if (this.currentTask != null) {
			return this.currentTask.getName();
		}
		else return "No current task";
	}
	
	public void setHoursLeft(double hours) {
		if (hours>=0.0 && hours <= MAX_DAILY_HOURS) {
			this.hoursLeft=hours;
		}
	}
	
	public double getHoursLeft() {
		return this.hoursLeft;
	}
	
	public Employee(String name) {
		this.setName(name);
		this.setHoursLeft(MAX_DAILY_HOURS);
		
	}
	
	public void work() {
		if(this.currentTask != null) {
			if (this.hoursLeft > 0.0) {
				if(this.currentTask.getWorkingHours() >= this.hoursLeft) {
					
					this.currentTask.setWorkingHours(this.currentTask.getWorkingHours()-this.hoursLeft);
					this.setHoursLeft(0);
				}
				else {
					this.setHoursLeft(this.getHoursLeft()-this.currentTask.getWorkingHours());
					this.currentTask.setWorkingHours(0.0);
					
				}
			}
			else {
				System.out.println("The workday is over.");
			}
		}
		else {
			System.out.println("No current task.");
		}
	}
	
	public void showReport() {
		System.out.println(this.getName()+" has been working on "+this.currentTask.getName()+" . The employee has "
				+this.getHoursLeft()+" hours left and the task has "+ this.currentTask.getWorkingHours()+" left to complete.");
	}
	
	
}
