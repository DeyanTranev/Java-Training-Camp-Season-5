
public class DoWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Task writeReport = new Task("report writing", 4);
		Task collectPayroll = new Task ("collecting payroll", 18);
		
		Employee vasil = new Employee("Vasil Stoyanov");
		vasil.setCurrentTask(writeReport);
		
		Employee boris = new Employee("Boris Angelov");
		boris.setCurrentTask(collectPayroll);
		
		vasil.work();
		boris.work();
		
		vasil.showReport();
		boris.showReport();
			
		

	}

}
