
public class SimCard {
	String simMobileNumber;
	
	public SimCard(String simMobileNumber) {
		this.simMobileNumber = simMobileNumber;
	}
}
