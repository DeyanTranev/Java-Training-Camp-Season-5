
public class Call {
	double priceForAMinute = 0.15;
	GSM caller;
	GSM receiver;
	int duration;
}
