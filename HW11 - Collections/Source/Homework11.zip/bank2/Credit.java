package bank2;

public class Credit extends Account {

	protected Credit(String holderName, double amount, int interest, int months) {
		super(holderName, amount, interest, months);
		// TODO Auto-generated constructor stub
	}

}
