package bank2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Client implements IClient {
	private String name;
	private String address;
	private double money;
	private double monthlySalary;
	private Bank bank;
	List<Deposit> deposits;
	List<Credit> credits;
	
	protected Client(String name, String address, double money, double monthlySalary) {
		this.name = name;
		this.address = address;
		this.money = money;
		this.monthlySalary = monthlySalary;
		this.deposits = new ArrayList<Deposit>();
		this.credits = new ArrayList<Credit>();
	}
	protected void setBank(Bank bank) {
		if (bank != null) {
			this.bank = bank;
		}
	}
	@Override
	public void openDeposit(double amount, int months) {
		if (this.money > 0 && amount <= this.money) {
			this.money -= amount;
			this.deposits.add(bank.acceptDeposit(this.name, amount));
		}
		
	}
	@Override
	public void applyForCredit(double amount, int months, double monthlySalary, List<Credit> credits) {
		Credit newCredit = this.bank.approveCredit(this.name, amount, months, monthlySalary, Collections.unmodifiableList(this.credits));
		if (newCredit !=  null) {
			newCredit.setMonthlyPayment(bank.calculateMonthlyInterestPayment(newCredit));
			this.credits.add(newCredit);
			this.money+=amount;
		}
		
	}
	@Override
	public void makeCreditPayment() {
		
		
	}
}
