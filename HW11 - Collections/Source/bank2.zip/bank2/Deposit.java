package bank2;

public class Deposit extends Account {

	protected Deposit(String holderName, double balance, int annualInterest, int months) {
		super(holderName, balance, annualInterest, months);
		// TODO Auto-generated constructor stub
	}
	
}
