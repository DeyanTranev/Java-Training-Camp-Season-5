package bank2;

import java.util.List;

public interface IClient {
	void openDeposit(double amount, int months);
	void applyForCredit(double amount, int months, double monthlySalary, List<Credit> credits);
	void makeCreditPayment();
}
