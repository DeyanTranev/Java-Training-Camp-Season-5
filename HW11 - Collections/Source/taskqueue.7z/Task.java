package taskqueue;

public interface Task {
	void doWork();
}
