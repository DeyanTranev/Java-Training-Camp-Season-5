package taskqueue;

import java.util.LinkedList;
import java.util.Queue;

public class Scheduler {
	Queue<Task> tasks;
	void push(Task t) {
		this.tasks.offer(t);
	}
}
