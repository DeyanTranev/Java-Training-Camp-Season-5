package taskqueue;

import java.util.LinkedList;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scheduler s = new Scheduler();
		s.tasks = new LinkedList<Task>();
		Coding c1 = new Coding();
		Driving d1 = new Driving();
		Teaching t1 = new Teaching();
		Building b1 = new Building();
		s.push(c1);
		s.push(d1);
		s.push(t1);
		s.push(b1);
		while(!s.tasks.isEmpty()) {
			s.tasks.poll().doWork();
		}
	}

}
