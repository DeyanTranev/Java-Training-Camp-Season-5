package taskqueue;

public class Coding implements Task{

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
		System.out.println("Coding collections with lambda expressions");
	}

}
