package taskqueue;

public class Driving implements Task{

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
		System.out.println("Just driving...");
	}

}
