package taskqueue;

public class Teaching implements Task{

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
		System.out.println("Ucha gi tiq na Java");
	}

}
