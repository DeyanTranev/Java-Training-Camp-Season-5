package taskqueue;

public class Building implements Task{

	@Override
	public void doWork() {
		// TODO Auto-generated method stub
		System.out.println("Laying bricks");
	}
	
}
